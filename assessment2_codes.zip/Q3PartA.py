import unittest

def percentage(num1, num2):
    if num1 > 0 and num2 > 0 and num1 < num2:
        return (num1 / num2) * 100
    else:
        return -1



