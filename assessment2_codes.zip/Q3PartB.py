def test_reactor_warning_message():
    def get_reactor_warning_message(temperature):
        if temperature < 300:
            return "Danger: temperature is below 300 degrees."
        elif 300 <= temperature <= 650:
            return "Warning: temperature is between 300 and 650."
        elif 650 < temperature <= 800:
            return "The reactor is operating within the standard range of 650 to 800."
        elif 800 < temperature <= 950:
            return "The reactor is operating within the standard range of 800 to 950."
        elif 950 < temperature < 1100:
            return "Warning: temperature is above 950 but below 1100."
        elif temperature >= 1100:
            return "Danger: temperature is above 1100."
