import unittest

class TestGuessingGame(unittest.TestCase):
    def test_part_A(self):
        # Test case 1: Test input below lower bound
        # Test expectation: Print "Too low"
        answer = 42
        guess = int(input("Guess a number between 1 and 100: "))
        while guess != answer:
            if guess < answer:
                print("Too low")
            else:
                print("Too high")
            guess = int(input("Guess again: "))
        self.assertEqual(print("Too low"), "Too low")

        # Test case 2: Test input at lower bound
        # Test expectation: Print "Too low"
        answer = 42
        guess = int(input("Guess a number between 1 and 100: "))
        while guess != answer:
            if guess < answer:
                print("Too low")
            else:
                print("Too high")
            guess = int(input("Guess again: "))
        self.assertEqual(print("Too low"), "Too low")
        
    def test_part_B(self):
        # Test case 3: Test input at upper bound
        # Test expectation: Print "Too high"
        answer = 42
        guess = int(input("Guess a number between 1 and 100: "))
        while guess != answer:
            if guess < answer:
                print("Too low")
            else:
                print("Too high")
            guess = int(input("Guess again: "))
        self.assertEqual(print("Too high"), "Too high")

        # Test case 4: Test input above upper bound
        # Test expectation: Print "Too high"
        answer = 42
        guess = int(input("Guess a number between 1 and 100: "))
        while guess != answer:
            if guess < answer:
                print("Too low")
            else:
                print("Too high")
            guess = int(input("Guess again: "))
        self.assertEqual(print("Too high"), "Too high")

    def test_part_C(self):
        # Test case 5: Test input at answer
        # Test expectation: Print "You got it!"
        answer = 42
        guess = int(input("Guess a number between 1 and 100: "))
        while guess != answer:
            if guess < answer:
                print("Too low")
            else:
                print("Too high")
            guess = int(input("Guess again: "))
        self.assertEqual(print("You got it!"), "You got it!")
        
if __name__ == '__main__':
    unittest.main()

