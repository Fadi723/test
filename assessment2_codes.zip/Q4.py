import random

class Game:
    def __init__(self, player_one_beast, player_two_beast):
        self.player_one_health = 50
        self.player_two_health = 50
        self.player_one_beast = player_one_beast
        self.player_two_beast = player_two_beast

    def attack(self, dice_type, dice_number, is_defending):
        
        total = 0
        if is_defending:
            print("Defending!")
        else:
            for _ in range(dice_number):
                total = total + random.randint(1, dice_type)
        return total

    def print_attack_message(self, player_one_attack, player_two_attack, current_player):
     
        if current_player == 1:
            print(f"{self.player_one_beast} attacks {self.player_two_beast} for {player_one_attack} damage")
        elif current_player == 2:
            print(f"{self.player_two_beast} attacks {self.player_one_beast} for {player_two_attack} damage")

    def play_game(self):
        while self.player_one_health > 0 and self.player_two_health > 0:
            print(f"{self.player_one_beast}'s health: {self.player_one_health}")
            print(f"{self.player_two_beast}'s health: {self.player_two_health}")
            player_one_defend = input("Player 1, do you want to defend? (y/n): ")
            player_two_defend = input("Player 2, do you want to defend? (y/n): ")
            if player_one_defend == "y":
                player_one_attack = self.attack(6, 2, True)
            else:
                player_one_attack = self.attack(6, 2, False)

            if player_two_defend == "y":
                player_two_attack = self.attack(6, 2, True)
            else:
                player_two_attack = self.attack(6, 2, False)
            
            self.player_one_health = self.player_one_health - player_two_attack
            self.player_two_health = self.player_two_health - player_one_attack
            self.print_attack_message(player_one_attack, player_two_attack, 1)
            self.print_attack_message(player_one_attack, player_two_attack, 2)

    def print_winner(self):
        
        if self.player_one_health <= 0:
            print(f"{self.player_two_beast} wins!")
       

